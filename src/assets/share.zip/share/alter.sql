ALTER TABLE `medalfa`.`entradasalida` MODIFY COLUMN `sumatoria` INTEGER UNSIGNED;



DROP TRIGGER IF EXISTS movimiento_i;
DELIMITER ;;
CREATE TRIGGER movimiento_i BEFORE INSERT ON entradasalida FOR EACH ROW BEGIN

    DECLARE suma integer;

    SELECT sumatoria INTO suma FROM entradasalida where productoId = NEW.productoId order by id desc limit 1;

    IF ISNULL(suma) THEN
      SET suma = 0;
    END IF;

    IF NEW.tipo = 0 THEN
      SET NEW.sumatoria = suma + NEW.cantidad;
    ELSE
      SET NEW.sumatoria = suma - NEW.cantidad;
    END IF;



  END ;;
DELIMITER ;


CREATE USER 'medalfa'@'localhost' IDENTIFIED BY 'medalfa';
GRANT ALL PRIVILEGES ON medalfa.* TO 'medalfa'@'localhost';

flush privileges;