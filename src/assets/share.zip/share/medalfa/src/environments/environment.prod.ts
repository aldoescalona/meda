export const environment = {
  production: true,
  API_URL: 'http://34.234.189.160/medalfa/v1',
};
