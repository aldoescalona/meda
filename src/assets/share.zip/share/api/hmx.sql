-- MySQL dump 10.13  Distrib 5.6.2-m5, for Win32 (x86)
--
-- Host: localhost    Database: hmx
-- ------------------------------------------------------
-- Server version	5.6.2-m5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_sequences`
--

DROP TABLE IF EXISTS `_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_sequences` (
  `name` varchar(70) NOT NULL,
  `next` int(11) NOT NULL,
  `inc` int(11) NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `correo` varchar(45) NOT NULL,
  `contrasena` varchar(45) NOT NULL,
  `cambioContrasena` tinyint(1) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `hard` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `click`
--

DROP TABLE IF EXISTS `click`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `click` (
  `id` bigint(20) unsigned NOT NULL,
  `usuarioId` bigint(20) unsigned NOT NULL,
  `direccionIp` varchar(22) NOT NULL,
  `fecha` datetime NOT NULL,
  `tiempo` int(10) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `clase` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_clic_usuario` (`usuarioId`),
  KEY `FK_clic_lugar` (`lugarId`),
  CONSTRAINT `FK_clic_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`),
  CONSTRAINT `FK_clic_usuario` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `correo` varchar(90) NOT NULL,
  `passsword` varchar(90) NOT NULL,
  `cambiarPasssword` tinyint(1) NOT NULL,
  `estado` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `codigopostal`
--

DROP TABLE IF EXISTS `codigopostal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codigopostal` (
  `id` int(10) unsigned NOT NULL,
  `codigo` varchar(8) NOT NULL,
  `asentamiento` varchar(75) NOT NULL,
  `tipoAsentamientoId` int(10) unsigned NOT NULL,
  `municipioId` int(10) unsigned NOT NULL,
  `estadoId` int(10) unsigned NOT NULL,
  `ciudad` varchar(80) DEFAULT NULL,
  `cobertura` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra` (
  `id` bigint(20) unsigned NOT NULL,
  `usuarioId` bigint(20) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `ofertaId` bigint(20) unsigned NOT NULL,
  `puntos` int(10) unsigned NOT NULL,
  `fecha` datetime NOT NULL,
  `estado` int(10) unsigned NOT NULL,
  `folio` int(10) unsigned NOT NULL,
  `fechaRespuesta` datetime DEFAULT NULL,
  `operadorId` bigint(20) unsigned DEFAULT NULL,
  `respuesta` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_compra_usuario` (`usuarioId`),
  KEY `FK_compra_lugar` (`lugarId`),
  KEY `FK_compra_operador` (`operadorId`),
  KEY `FK_compra_oferta` (`ofertaId`),
  CONSTRAINT `FK_compra_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`),
  CONSTRAINT `FK_compra_oferta` FOREIGN KEY (`ofertaId`) REFERENCES `oferta` (`id`),
  CONSTRAINT `FK_compra_operador` FOREIGN KEY (`operadorId`) REFERENCES `operador` (`id`),
  CONSTRAINT `FK_compra_usuario` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50003 TRIGGER compra_u AFTER UPDATE ON compra FOR EACH ROW BEGIN

   UPDATE pagocompra SET estado = NEW.estado WHERE compraId = OLD.id;

   IF OLD.estado = 0 AND NEW.estado = 1 THEN
     INSERT INTO historiapuntos(usuarioId, lugarId, ofertaId, tipo, descripcion, puntos, fecha) VALUES(NEW.usuarioId, NEW.lugarId, NEW.ofertaId, 1,null, NEW.puntos, now());
   END IF;
  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `convenio`
--

DROP TABLE IF EXISTS `convenio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `convenio` (
  `id` bigint(20) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `relacionadoId` bigint(20) unsigned NOT NULL,
  `tipo` int(10) unsigned NOT NULL,
  `estado` int(10) unsigned NOT NULL,
  `tasa` decimal(6,2) NOT NULL,
  `tope` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_convenio_lugar` (`lugarId`),
  KEY `FK_convenio_lugarrelacionado` (`relacionadoId`),
  CONSTRAINT `FK_convenio_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`),
  CONSTRAINT `FK_convenio_lugarrelacionado` FOREIGN KEY (`relacionadoId`) REFERENCES `lugar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `estado`
--

DROP TABLE IF EXISTS `estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado` (
  `id` int(10) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `evento`
--

DROP TABLE IF EXISTS `evento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evento` (
  `id` bigint(20) unsigned NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `fechaInicio` datetime NOT NULL,
  `fechaFin` datetime DEFAULT NULL,
  `estado` int(10) unsigned NOT NULL,
  `imagenId` bigint(20) unsigned DEFAULT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `tipo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_cartelera_imagen` (`imagenId`),
  KEY `FK_cartelera_lugar` (`lugarId`),
  CONSTRAINT `FK_cartelera_imagen` FOREIGN KEY (`imagenId`) REFERENCES `imagen` (`id`),
  CONSTRAINT `FK_cartelera_lugfar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `historiapuntos`
--

DROP TABLE IF EXISTS `historiapuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historiapuntos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuarioId` bigint(20) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `ofertaId` bigint(20) unsigned DEFAULT NULL,
  `tipo` int(10) unsigned NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `puntos` int(10) unsigned NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_acumulador_usuarioId` (`usuarioId`),
  KEY `FK_acumulador_lugar` (`lugarId`),
  KEY `FK_acumulador_oferta` (`ofertaId`),
  CONSTRAINT `FK_historiapuntos_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`),
  CONSTRAINT `FK_historiapuntos_oferta` FOREIGN KEY (`ofertaId`) REFERENCES `oferta` (`id`),
  CONSTRAINT `FK_historiapuntos_usuarioId` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=153844904062239 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagen`
--

DROP TABLE IF EXISTS `imagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagen` (
  `id` bigint(20) unsigned NOT NULL,
  `imgA` varchar(110) NOT NULL,
  `imgB` varchar(110) NOT NULL,
  `imgC` varchar(110) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lugar`
--

DROP TABLE IF EXISTS `lugar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lugar` (
  `id` bigint(20) unsigned NOT NULL,
  `ciudadId` int(10) unsigned NOT NULL,
  `codigoPostalId` int(10) unsigned NOT NULL,
  `segmentoId` bigint(20) unsigned NOT NULL,
  `propietarioId` bigint(20) unsigned NOT NULL,
  `imagenLogoId` bigint(20) unsigned DEFAULT NULL,
  `imagenPortadaId` bigint(20) unsigned DEFAULT NULL,
  `tipo` int(10) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `alias` varchar(16) NOT NULL,
  `direccion` varchar(150) NOT NULL,
  `calificacion` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `calificaciones` int(10) unsigned NOT NULL DEFAULT '0',
  `calificacion5` int(10) NOT NULL DEFAULT '0',
  `calificacion4` int(10) NOT NULL DEFAULT '0',
  `calificacion3` int(10) NOT NULL DEFAULT '0',
  `calificacion2` int(10) NOT NULL DEFAULT '0',
  `calificacion1` int(10) NOT NULL DEFAULT '0',
  `descripcion` varchar(250) NOT NULL,
  `telefono` varchar(18) DEFAULT NULL,
  `sitioWeb` varchar(140) DEFAULT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `ubicacionUrl` varchar(180) DEFAULT NULL,
  `ubicacionLng` varchar(25) DEFAULT NULL,
  `ubicacionLtd` varchar(25) DEFAULT NULL,
  `precioMin` decimal(5,2) DEFAULT NULL,
  `precioMax` decimal(5,2) DEFAULT NULL,
  `puntosGenerados` decimal(7,2) DEFAULT '0.00',
  `puntosCanjeados` decimal(7,2) DEFAULT '0.00',
  `puntosCanjeadosOtros` decimal(7,2) DEFAULT '0.00',
  `orden` int(10) unsigned NOT NULL DEFAULT '100',
  `foliadorCompras` int(10) unsigned NOT NULL DEFAULT '1',
  `estado` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `FK_lugar_ciudad` (`ciudadId`),
  KEY `FK_lugar_cp` (`codigoPostalId`),
  KEY `FK_lugar_segmento` (`segmentoId`),
  KEY `FK_lugar_cliente` (`propietarioId`),
  KEY `FK_lugar_imagenlogo` (`imagenLogoId`),
  KEY `FK_lugar_imagenport` (`imagenPortadaId`),
  CONSTRAINT `FK_lugar_ciudad` FOREIGN KEY (`ciudadId`) REFERENCES `municipio` (`id`),
  CONSTRAINT `FK_lugar_cliente` FOREIGN KEY (`propietarioId`) REFERENCES `cliente` (`id`),
  CONSTRAINT `FK_lugar_cp` FOREIGN KEY (`codigoPostalId`) REFERENCES `codigopostal` (`id`),
  CONSTRAINT `FK_lugar_imagenlogo` FOREIGN KEY (`imagenLogoId`) REFERENCES `imagen` (`id`),
  CONSTRAINT `FK_lugar_imagenport` FOREIGN KEY (`imagenPortadaId`) REFERENCES `imagen` (`id`),
  CONSTRAINT `FK_lugar_segmento` FOREIGN KEY (`segmentoId`) REFERENCES `segmento` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `municipio`
--

DROP TABLE IF EXISTS `municipio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipio` (
  `id` int(10) unsigned NOT NULL,
  `estadoId` int(10) unsigned NOT NULL,
  `clave` int(10) unsigned NOT NULL,
  `nombre` varchar(75) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oferta`
--

DROP TABLE IF EXISTS `oferta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oferta` (
  `id` bigint(20) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `tipo` int(10) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `condiciones` varchar(150) DEFAULT NULL,
  `precio` int(10) unsigned NOT NULL,
  `orden` int(10) unsigned NOT NULL,
  `imagenId` bigint(20) unsigned DEFAULT NULL,
  `calificacion` decimal(5,2) unsigned DEFAULT '0.00',
  `calificaciones` int(10) unsigned NOT NULL DEFAULT '0',
  `calificacion5` int(10) NOT NULL DEFAULT '0',
  `calificacion4` int(10) NOT NULL DEFAULT '0',
  `calificacion3` int(10) NOT NULL DEFAULT '0',
  `calificacion2` int(10) NOT NULL DEFAULT '0',
  `calificacion1` int(10) NOT NULL DEFAULT '0',
  `vendidos` int(10) unsigned NOT NULL DEFAULT '0',
  `estado` int(10) unsigned NOT NULL,
  `baja` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_oferta_lugar` (`lugarId`),
  KEY `FK_oferta_imagen` (`imagenId`),
  CONSTRAINT `FK_oferta_imagen` FOREIGN KEY (`imagenId`) REFERENCES `imagen` (`id`),
  CONSTRAINT `FK_oferta_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operador`
--

DROP TABLE IF EXISTS `operador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operador` (
  `id` bigint(20) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `clave` varchar(12) NOT NULL,
  `contrasena` varchar(120) DEFAULT NULL,
  `estado` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_operador_lugar` (`lugarId`),
  CONSTRAINT `FK_operador_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pagocompra`
--

DROP TABLE IF EXISTS `pagocompra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagocompra` (
  `id` bigint(20) unsigned NOT NULL,
  `compraId` bigint(20) unsigned NOT NULL,
  `origenId` bigint(20) unsigned NOT NULL,
  `puntos` float NOT NULL,
  `estado` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_pagocompra_compra` (`compraId`),
  KEY `FK_pagocompra_origen` (`origenId`),
  CONSTRAINT `FK_pagocompra_compra` FOREIGN KEY (`compraId`) REFERENCES `compra` (`id`),
  CONSTRAINT `FK_pagocompra_origen` FOREIGN KEY (`origenId`) REFERENCES `lugar` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50003 TRIGGER pagocompra_i AFTER INSERT ON pagocompra FOR EACH ROW BEGIN

    DECLARE lgrId bigint;
    DECLARE usrId bigint;

    SET lgrId = 0;
    SET usrId = 0;

    SELECT usuarioId, lugarId INTO usrId, lgrId FROM compra where id = NEW.compraId;
    UPDATE usuariopuntos SET retenidos = retenidos + NEW.puntos WHERE usuarioId = usrId AND lugarId = NEW.origenId;
    UPDATE usuario set retenidos = retenidos + NEW.puntos where id = usrId;

  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50003 TRIGGER pagocompra_u AFTER UPDATE ON pagocompra FOR EACH ROW BEGIN

   DECLARE lgrId bigint;
   DECLARE usrId bigint;
   DECLARE existe int;

   SET lgrId = 0;
   SET usrId = 0;
   SET existe = 0;

   SELECT usuarioId, lugarId INTO usrId, lgrId FROM compra where id = NEW.compraId;

   IF OLD.estado = 0 AND NEW.estado = 1 THEN

     UPDATE usuariopuntos SET puntos = puntos - NEW.puntos, retenidos = retenidos - NEW.puntos WHERE usuarioId = usrId AND lugarId = NEW.origenId;
     UPDATE usuario SET puntos = puntos - NEW.puntos, retenidos = retenidos - NEW.puntos where id = usrId;

     IF NEW.origenId != lgrId THEN

      SELECT 1 INTO existe FROM colocacion where origenId = NEW.origenId AND destinoId = lgrId;

      IF existe <= 0 THEN
       INSERT INTO colocacion(origenId, destinoId, puntos)VALUES(NEW.origenId, lgrId, 0);
      END IF;

      UPDATE colocacion SET puntos = puntos + NEW.puntos WHERE origenId = NEW.origenId AND destinoId = lgrId;

      UPDATE lugar set puntosCanjeadosOtros = puntosCanjeadosOtros + NEW.puntos where id = NEW.origenId;

     ELSE  
      UPDATE lugar set puntosCanjeados = puntosCanjeados + NEW.puntos where id = lgrId;
     END IF;

   ELSEIF  OLD.estado = 0 AND NEW.estado = 2 THEN

     UPDATE usuariopuntos SET retenidos = retenidos - NEW.puntos WHERE usuarioId = usrId AND lugarId = NEW.origenId;
     UPDATE usuario set retenidos = retenidos - NEW.puntos where id = usrId;
   END IF;
  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `parametro`
--

DROP TABLE IF EXISTS `parametro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parametro` (
  `nombre` varchar(25) NOT NULL,
  `valor` varchar(45) NOT NULL,
  PRIMARY KEY (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `segmento`
--

DROP TABLE IF EXISTS `segmento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `segmento` (
  `id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `orden` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tipoasentamiento`
--

DROP TABLE IF EXISTS `tipoasentamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipoasentamiento` (
  `id` int(10) unsigned NOT NULL,
  `tipo` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `sexo` int(10) unsigned DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  `contrasena` varchar(120) DEFAULT NULL,
  `facebookid` varchar(40) DEFAULT NULL,
  `imagenURL` varchar(150) DEFAULT NULL,
  `puntos` int(10) unsigned NOT NULL DEFAULT '0',
  `retenidos` int(10) unsigned NOT NULL DEFAULT '0',
  `estado` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuariopuntos`
--

DROP TABLE IF EXISTS `usuariopuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuariopuntos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuarioId` bigint(20) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `puntos` int(10) unsigned NOT NULL,
  `retenidos` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_usuariopuntos_usuario` (`usuarioId`),
  KEY `FK_usuariopuntos_lugar` (`lugarId`),
  CONSTRAINT `FK_usuariopuntos_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`),
  CONSTRAINT `FK_usuariopuntos_usuario` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `visita`
--

DROP TABLE IF EXISTS `visita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visita` (
  `id` bigint(20) unsigned NOT NULL,
  `usuarioId` bigint(20) unsigned NOT NULL,
  `lugarId` bigint(20) unsigned NOT NULL,
  `calificacion` int(10) unsigned NOT NULL,
  `resena` varchar(100) DEFAULT NULL,
  `ticket` varchar(20) NOT NULL,
  `monto` decimal(9,2) NOT NULL,
  `fecha` datetime NOT NULL,
  `fechaRespuesta` datetime DEFAULT NULL,
  `operadorId` bigint(20) unsigned DEFAULT NULL,
  `respuesta` varchar(45) DEFAULT NULL,
  `estado` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_visita_usuario` (`usuarioId`),
  KEY `FK_visita_lugar` (`lugarId`),
  KEY `FK_visita_operador` (`operadorId`),
  CONSTRAINT `FK_visita_lugar` FOREIGN KEY (`lugarId`) REFERENCES `lugar` (`id`),
  CONSTRAINT `FK_visita_operador` FOREIGN KEY (`operadorId`) REFERENCES `operador` (`id`),
  CONSTRAINT `FK_visita_usuario` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50003 TRIGGER visita_u AFTER UPDATE ON visita FOR EACH ROW BEGIN

   DECLARE existe int;

   SET existe = 0;

   IF OLD.estado = 0 AND NEW.estado = 1 THEN

    INSERT INTO historiapuntos(usuarioId, lugarId, ofertaId, tipo, descripcion, puntos, fecha) VALUES(NEW.usuarioId, NEW.lugarId, null, 0,null, FLOOR(NEW.monto), now());
    SELECT 1 INTO existe FROM usuariopuntos where usuarioId = NEW.usuarioId AND lugarId = NEW.lugarId;

    IF existe <= 0 THEN
     INSERT INTO usuariopuntos(usuarioId, lugarId, puntos)VALUES(NEW.usuarioId, NEW.lugarId, 0);
    END IF;
   
    UPDATE usuariopuntos set puntos = puntos + FLOOR(NEW.monto) where usuarioId = NEW.usuarioId AND lugarId = NEW.lugarId;
    UPDATE usuario set puntos = puntos + FLOOR(NEW.monto) where id = NEW.usuarioId; 
    UPDATE lugar set puntosGenerados = puntosGenerados + FLOOR(NEW.monto) where id = NEW.lugarId;

   END IF;

  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-03 15:54:25



DELIMITER $$

DROP FUNCTION IF EXISTS `hmx`.`NextCompra`$$
CREATE FUNCTION  `hmx`.`NextCompra`(vname BIGINT) RETURNS int(11)
BEGIN
          UPDATE lugar
       SET foliadorCompras = (@next := foliadorCompras) + 1
       WHERE id = vname;

     RETURN @next;
  END;

 $$

DELIMITER ;

DELIMITER $$

DROP FUNCTION IF EXISTS `hmx`.`NextVal`$$
CREATE FUNCTION  `hmx`.`NextVal`(vname VARCHAR(30)) RETURNS int(11)
BEGIN
          UPDATE _sequences
       SET next = (@next := next) + 1
       WHERE name = vname;

     RETURN @next;
  END;

 $$

DELIMITER ;
